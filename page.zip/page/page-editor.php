<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Artist profile Editor</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    
    
    
<script type="text/javascript">


function init() {
hideMediaList();
  hideAudioForm();
hideVideoForm();
	hideAnchor();

	}
  </script>
    
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    

/* ==========================================================================
   Author's custom styles
   ========================================================================== */

body
{
    font-family: 'Open Sans', sans-serif;
}

.fb-profile img.fb-image-lg{
    z-index: 0;
    width: 100%;  
    margin-bottom: 10px;
}

.fb-image-profile
{
    margin: -90px 10px 0px 50px;
    z-index: 9;
    width: 20%; 
}

@media (max-width:768px)
{
    
.fb-profile-text>h1{
    font-weight: 700;
    font-size:16px;
}

.fb-image-profile
{
    margin: -45px 10px 0px 25px;
    z-index: 9;
    width: 20%; 
}
}
    </style>
    <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'http://bootsnipp.com');
        });
    </script>
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <style type="text/css">
    /***
User Profile Sidebar by @keenthemes
A component of Metronic Theme - #1 Selling Bootstrap 3 Admin Theme in Themeforest: http://j.mp/metronictheme
Licensed under MIT
***/

body {
  background: #F1F3FA;
}

/* Profile container */
.profile {
  margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
  padding: 20px 0 10px 0;
  background: #fff;
}

.profile-userpic img {
  float: none;
  margin: 0 auto;
  width: 50%;
  height: 50%;
  -webkit-border-radius: 50% !important;
  -moz-border-radius: 50% !important;
  border-radius: 50% !important;
}

.profile-usertitle {
  text-align: center;
  margin-top: 20px;
}

.profile-usertitle-name {
  color: #5a7391;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 7px;
}

.profile-usertitle-job {
  text-transform: uppercase;
  color: #5b9bd1;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
}

.profile-userbuttons {
  text-align: center;
  margin-top: 10px;
}

.profile-userbuttons .btn {
  text-transform: uppercase;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 15px;
  margin-right: 5px;
}

.profile-userbuttons .btn:last-child {
  margin-right: 0px;
}
    
.profile-usermenu {
  margin-top: 30px;
}

.profile-usermenu ul li {
  border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
  border-bottom: none;
}

.profile-usermenu ul li a {
  color: #93a3b5;
  font-size: 14px;
  font-weight: 400;
}

.profile-usermenu ul li a i {
  margin-right: 8px;
  font-size: 14px;
}

.profile-usermenu ul li a:hover {
  background-color: #fafcfd;
  color: #5b9bd1;
}

.profile-usermenu ul li.active {
  border-bottom: none;
}

.profile-usermenu ul li.active a {
  color: #5b9bd1;
  background-color: #f6f9fb;
  border-left: 2px solid #5b9bd1;
  margin-left: -2px;
}

/* Profile Content */
.profile-content {
  padding: 50px;
  background: #fff;
  min-height: 500px;
}
    </style>
    
  
  
   
  <link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    
  
  <link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
    
    
    <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
   
    <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'http://bootsnipp.com');
        });
    </script>
       
    
    
    
    <style type="text/css">
    @import url(http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css);
body{margin-top:50px;background: rgb(36, 39, 41);}

    </style>
    
    
    
    
    
     <style type="text/css">
    /***
User Profile Sidebar by @keenthemes
A component of Metronic Theme - #1 Selling Bootstrap 3 Admin Theme in Themeforest: http://j.mp/metronictheme
Licensed under MIT
***/

body {
  background: #F1F3FA;
}

/* Profile container */
.profile {
  margin: 20px 0;
}

/* Profile sidebar */
.profile-sidebar {
  padding: 20px 0 10px 0;
  background: #fff;
}

.profile-userpic img {
  float: none;
  margin: 0 auto;
  width: 50%;
  height: 50%;
  -webkit-border-radius: 50% !important;
  -moz-border-radius: 50% !important;
  border-radius: 50% !important;
}

.profile-usertitle {
  text-align: center;
  margin-top: 20px;
}

.profile-usertitle-name {
  color: #5a7391;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 7px;
}

.profile-usertitle-job {
  text-transform: uppercase;
  color: #5b9bd1;
  font-size: 12px;
  font-weight: 600;
  margin-bottom: 15px;
}

.profile-userbuttons {
  text-align: center;
  margin-top: 10px;
}

.profile-userbuttons .btn {
  text-transform: uppercase;
  font-size: 11px;
  font-weight: 600;
  padding: 6px 15px;
  margin-right: 5px;
}

.profile-userbuttons .btn:last-child {
  margin-right: 0px;
}
    
.profile-usermenu {
  margin-top: 30px;
}

.profile-usermenu ul li {
  border-bottom: 1px solid #f0f4f7;
}

.profile-usermenu ul li:last-child {
  border-bottom: none;
}

.profile-usermenu ul li a {
  color: #93a3b5;
  font-size: 14px;
  font-weight: 400;
}

.profile-usermenu ul li a i {
  margin-right: 8px;
  font-size: 14px;
}

.profile-usermenu ul li a:hover {
  background-color: #fafcfd;
  color: #5b9bd1;
}

.profile-usermenu ul li.active {
  border-bottom: none;
}

.profile-usermenu ul li.active a {
  color: #5b9bd1;
  background-color: #f6f9fb;
  border-left: 2px solid #5b9bd1;
  margin-left: -2px;
}

/* Profile Content */
.profile-content {
  padding: 50px;
  background: #fff;
  min-height: 500px;
}
    </style> 
    <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; font: 26.0px Helvetica; color: #ffffff; background-color: #050533; min-height: 40.0px}
  </style>
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
  

<script type="text/javascript">







function View(form) {
msg=open("","DisplayWindow","status=1,scrollbars=1");
msg.document.write(form.body.value);
}


function AddText(form, Action){
var AddTxt="";
var txt="";
if(Action==1){  
txt=prompt("Text for the level 1 header.","Text");      
if(txt!=null)           
AddTxt="<h2>"+txt+"</h2>\r\n";  
}
if(Action==25){  
txt=prompt("Text for the level 2 header.","Text");      
if(txt!=null)           
AddTxt="<h3>"+txt+"</h3>\r\n";  
}
if(Action==3){  
txt=prompt("Text for the level 3 header.","Text");      
if(txt!=null)           
AddTxt="<h4>"+txt+"</h4>\r\n";  
}


if(Action==4) {  
txt=prompt("Text to be made BOLD.","Text");     
if(txt!=null)           
AddTxt="<b>"+txt+"</b>";        
}



if(Action==5) {  
txt=prompt("Text to be italicized","Text");     
if(txt!=null)           
AddTxt="<i>"+txt+"</i>";        
}



if(Action==6) AddTxt="\r\n<p>";
if(Action==7) AddTxt="<br/>\r\n";
if(Action==8) AddTxt="<hr>\r\n";

if(Action==9) {  
      
if(txt!=null){          
AddTxt="<a href=\""+form.AnchorType.value+""+form.AnchorUrl.value+"\"  align=\""+form.alignment.value+"\">";              
              
AddTxt+=form.anchor.value+"</a>\r\n";         
   }
}
if(Action==30) { 
     
if(txt!=null){   
AddTxt="<a href=\""+form.linkType.value+""+form.url.value+"\" align=\""+form.linkalignment.value+"\"><h5>"+form.link.value+"</h5></a>\r\n";
  }
}  
  

if(Action==26){
if(txt!=null){
 AddTxt="<div style=\"POSITION: absolute;left:"+form.div_imageLeft.value+"px;top:"+form.div_imageTop.value+"px; Z-INDEX:1;\" align="+form.playeralignment.value+"><img alt=\""+form.imageAlt.value+"\" src=\""+form.image.value+"\" height=\""+form.imageHeight.value+"\" width=\""+form.imageWidth.value+"\" align=\""+form.imageAlignment.value+"\" border=\""+form.imageBorder.value+"\"/><div>\r\n";
}
}




if(Action==2){
if(txt!=null){   
AddTxt+="<div style=\"POSITION: absolute;left:"+form.flashplayer_div_left.value+"px;top:"+form.flashplayer_div_top.value+"px; Z-INDEX:100;\" align=\""+form.flash_div_alignment.value+"\">\r\n";


AddTxt+="<embed src=\""+form.flash_swfs_src.value+"\" width=\""+form.flashplayer_width.value+"\" height=\""+form.flashplayer_height.value+"\"id=\"StrobeMediaPlayback\"quality=\""+form.flashquality.value+"\"bgcolor=\"#000000\"name=\"StrobeMediaPlayback\"allowfullscreen=\""+form.fullscreen.value+"\"pluginspage=\"http://www.adobe.com/go/getflashplayer\"flashvars=\"&src="+form.flashvars_src.value+"&autoHideControlBar="+form.autoHideControlBar.value+"&streamType=recorded&autoPlay="+form.flashautoplay.value+"\" type=\"application/x-shockwave-flash\"> </embed></object></div>\r\n";

} 
}

if(Action==10) { 
txt=prompt("URL for Image","URL");
   
AddTxt="<img src=\""+txt+"\""; 
if(txt!=null){ 
txt=prompt("width for Image","width"); 
AddTxt+=" width=\""+txt+"\"";
txt=prompt("alt text for Image","alt text");  
AddTxt+=" alt=\""+txt+"\">";
}
}


if(Action==11) { 
  
if(txt!=null) 
AddTxt+="<div style=\"POSITION: absolute;left:"+form.div_heights.value+"px;top:"+form.div_widths.value+"px; Z-INDEX:100;\" align="+form.playeralignment.value+">\r\n";
AddTxt+="<embed src=\""+form.WindowVideoFile.value+"\" id=\""+form.id.value+"\" border=\""+form.border.value+"\" autostart=\""+form.autostart.value+"\" loop=\""+form.loop.value+"\" width=\""+form.PlayerWidth .value+"\" height=\""+form.PlayerHeight.value+"\" align=\""+form.playeralignment.value+"\"></div>\r\n";  
 
}

if(Action==12) {  
txt=prompt("Text to be made BOLD.","Text");     
if(txt!=null)           
AddTxt="<CENTER>"+txt+"</CENTER>";        
}

if(Action==13) {
if(txt!=null)
AddTxt="<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" summary=\"\">\r\n";
AddTxt+="<tr>\r\n";
AddTxt+="<td>";
AddTxt+="Texe</td>\r\n";
AddTxt+="</tr>\r\n";
AddTxt+="</table>\r\n"; 
}



if(Action==14) {
if(txt!=null)
AddTxt="<audio src=\""+form.audio.value+"\"    width=\""+form.audio_width.value+"\" controls=\"controls\"></audio>\r\n" ;  
} 

if(Action==15) {
if(txt!=null)
AddTxt="<video src=\""+form.video.value+"\" poster=\""+form.video_poster.value+"\"   width=\""+form.video_width.value+"\" controls=\"controls\"></video>\r\n" ;  
} 



if(Action==17) AddTxt="<p align=\"justify\">Your Text</p>\r\n";
if(Action==18) AddTxt="<p align=\"left\">Your Text</p>\r\n";
if(Action==19) AddTxt="<p align=\"center\"> Your Text</p>\r\n";
if(Action==20) AddTxt="<p align=right>Your Text </p>\r\n";

if(Action==21) AddTxt="<u> Your Text</u>\r\n";


if(Action==22) AddTxt="<li>Text<li>Text<li>Text</li>\r\n";


if(Action==23) AddTxt="<div  style=\"font-family: arial, verdana, helvetica; font-size: 11px; width: 200px;\"><ol start=\""+form.media_id.value+"\"><li class=\"media\"><a class=\"pull-left\" href=\"http://vga.smtvs.com/imusic-demo/m-new-menu-04.php?p="+form.media_id.value+"\"><img src=\"http://vga.smtvs.com/imusic-demo/cover_img/"+form.media_image.value+"\" width=\"77\" alt=\"\"></a><h4 class=\"media-heading\"><p class=\"by-author\">Title:&nbsp;"+form.media_name.value+"</h4>&nbsp;"+form.media_des.value+"</div></li>\r\n";
form.body.value+=AddTxt;

}
 </script>
	
<script type="text/javascript">

function hideAnchor()
{
document.getElementById('anchor').style.display = "none";
}
function showAnchor()
{

document.getElementById('anchor').style.display = "block";
}
  
  function hideMediaList()
{
document.getElementById('medialist').style.display = "none";
}
function showMediaList()
{

document.getElementById('medialist').style.display = "block";
}
  
  
 function hideAudioForm()
{
document.getElementById('audioform').style.display = "none";
}
function showAudioForm()
{

document.getElementById('audioform').style.display = "block";
}
 
 
 function hideVideoForm()
{
document.getElementById('videoform').style.display = "none";
}
function showVideoForm()
{

document.getElementById('videoform').style.display = "block";
}  
  
  
  
  
  </script>

<?php 

if (isset($_POST["filename"])) {
	$fname = $_POST["filename"];
	$file = stripslashes($_POST["file"]);
	$fp = @fopen($fname, "w");
	if ($fp) {
		fwrite($fp, $file);
		fclose($fp);
	}
	
}

if (isset($_GET["f"])) 
	$fname = stripslashes($_GET["f"]);
	if (file_exists($fname)) 
		$fp = @fopen($fname, "r");
		if (filesize($fname) !== 0) 
			$loadfile = fread($fp, filesize($fname));
			$loadfile = htmlspecialchars($loadfile);
			fclose($fp);
?>
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; font: 26.0px Helvetica; color: #ffffff; background-color: #050533; min-height: 40.0px}
  </style>
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
 <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
    
 <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="hpp://code.jquery.com/resources/demos/style.css">
  <style>
  #draggable { width: 350px; height: 300px; padding: 0.5em; }
  </style>
  <script>
  $(function() {
   $( "#draggable" ).draggable();
    $( "#draggable1" ).draggable();
     $( "#draggable2" ).draggable();
    $( "#draggable3" ).draggable();
    $( "#draggable4" ).draggable();
     $( "#draggable5" ).draggable();
    $( "#draggable6" ).draggable();
    $( "#draggable7" ).draggable();
     $( "#draggable8" ).draggable();
    $( "#draggable9" ).draggable();
    $( "#draggable10" ).draggable();
     $( "#draggable11" ).draggable();
    $( "#draggable12" ).draggable();
  });
  </script>
   <style>
  #resizable { width: 150px; height: 150px; padding: 0.5em; }
  #resizable h3 { text-align: center; margin: 0; }
  </style>
  <script>
  $(function() {
    $( "#resizable" ).resizable();
  });
  </script>
  
</head>
<body  onLoad="init();">

	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
 <!-- /container -->  


<div class="container">
    <div class="row profile">
		<div class="col-md-3">
			<div class="profile-sidebar">
				<!-- SIDEBAR USERPIC -->
				
				
				<div class="profile-userpic">
				
				</div>
				<!-- END SIDEBAR USERPIC -->
				<!-- SIDEBAR USER TITLE -->
				<div class="profile-usertitle">
					<div class="profile-usertitle-name">
					
					</div>
					<div class="profile-">
					
					</div>
				</div>
				<!-- END SIDEBAR USER TITLE -->
				<!-- SIDEBAR BUTTONS -->
				
				<div class="profile-userbuttons">
						</div>
				<!-- END SIDEBAR BUTTONS -->
				<!-- SIDEBAR MENU -->
				<div class="profile-usermenu">
					<ul class="nav">
						<li class="active">
							<a href="http://vga.smtvs.com/imusic-demo/artist-pagemaneger box.php">
							<i class="glyphicon glyphicon-home"></i>
							Overview </a>
						</li>
						<li>
							<a href="#">
							<i class="glyphicon glyphicon-user"></i>
							Account Settings </a>
						</li>
						<li>
							<a href="" target="_blank">
							<i class="glyphicon glyphicon-envelope"></i>
							Check your email </a>
						</li>
						
						
						
						<li class="">
						
						<a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=artist-name.html"><i class="glyphicon glyphicon-edit"></i>Update-Artist Name </a> 
		
						 	
						</li>
						
						
						<li class="">
						<a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=short-bio.html"><i class="glyphicon glyphicon-edit"></i>Update-Artist-short-Biography </a> 
		
						 	
						</li>
						
						
						
						<li class="">
						<a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=biography.html"><i class="glyphicon glyphicon-edit"></i>Artist- Biography page </a>

						</li>
						
						
						
						
						<li class="">
						       
                  <a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=discography.html"> <i class="glyphicon glyphicon-edit"></i> Artist-Discography page</a>
         
							
						</li>
						
						
						
						<li class="">
						  <a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=events.html"><i class="glyphicon glyphicon-edit"></i>Update-Artist-Events</a> 
		
							
						</li>
						
						
						
						<li class="">
						
						 <a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=video.html" ><i class="glyphicon glyphicon-edit"></i> Update Video Page</a>
							
						</li>
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						<li>
							<a href="#" target="_blank">
							<i class="glyphicon glyphicon-upload"></i>
							Upload images </a>
						</li>
						
						<li>
							<a href="http://vga.smtvs.com/imusic-demo/artist-image-upload-box.php" target="_blank">
							<i class="glyphicon glyphicon-upload"></i>
							Upload Song image</a>
						</li>
						<li>
							<a href="http://vga.smtvs.com/imusic-demo/artist-song-upload-box.php" target="_blank">
							<i class="glyphicon glyphicon-upload"></i>
							Upload Your  Song </a>
						</li>
						
						<li class="">
						  <a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=song-list.html"><i class="glyphicon glyphicon-edit"></i>Update Song Playlist</a> 
		
							
						</li>
						
						
						
						
					
						
					
						
						<li>
							<a href="http://vga.smtvs.com/imusic-demo/video-image-upload-box.php" target="_blank">
							<i class="glyphicon glyphicon-upload"></i>
							Upload Video image</a>
						</li>
						
						<li>
							
				<a href="http://vga.smtvs.com/imusic-demo/artist-video-upload-box.php" target="_blank">

							<i class="glyphicon glyphicon-upload"></i>
							Upload Your  Video </a>
						</li>
								
						<li class="">
						  <a href="http://vga.smtvs.com/imusic-demo/page/page-editor.php?f=video-list.html"><i class="glyphicon glyphicon-edit"></i>Update Video Playlist</a> 
		
							
						</li>
						
						<li>
							<a href="#" target="_blank">
							<i class="glyphicon glyphicon-edit"></i>
							 Update   Social Links </a>
						</li>
						
						<li>
							<a href="#" target="_blank">
							<i class="glyphicon glyphicon-signal"></i>
							Media & Site Tracking </a>
						</li>
						
						
						<li>
							<a href="#">
							<i class="glyphicon glyphicon-flag"></i>
							Help </a>
						</li>
					</ul>
				</div>
				<!-- END MENU -->
			</div>
		</div>

		<div class="col-md-9">
            <div class="profile-content">
          <form  method="post" action="" >
          
            
          
           <div id="medialist">
        <div id="draggable4" class="panel panel-default" style="Z-INDEX: 27; POSITION: absolute; background-color: #F7F7F7; Width:300px;  TOP: 266px; LEFT: 15px;">
        <div class="panel-heading" >
                      Media  list Properties
                        </div>
 <div class="panel-body" >
        
		Insert
<button type="button" class="btn btn-default"  onclick="AddText(this.form,23);return false;" data-toggle="tooltip" title="Media list">
                            <i class="fa fa-list-ol"></i>
                        </button>
 <br/><br/>
            <input class="form-control" type="text" name="media_name" id="media_name" value="name" size="59" /><br/><br>
<input class="form-control" type="text" name="media_image" value="image" size="59" /><br/><br>
<input class="form-control" type="text" name="media_id" value="id" id="media_id" size="59" /><br/><br>
<textarea class="form-control" name="media_des" id="media_des" rows="4" cols="61"></textarea>

<P>

<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 147px; width: 62px;top:0px;" onClick="hideMediaList();return false;">Close</button>
    
  <P>                   
                        
 
 

                   
                        
</div> </div></div></div>
  
      
         
 <div class="panel panel-danger" style="Z-INDEX: 2; POSITION: absolute; background-color: #F7F7F7;   TOP: 66px; LEFT: 15px">
 <div class="row">
        <div class="col-md-12">
                <div class="panel-heading">
          <div class="btn-group">
                     
                        <button type="button" class="btn btn-default"onclick="AddText(this.form,4);return false;" data-toggle="tooltip" title="Bold">
                            <i class="fa fa-bold"></i>
                        </button>
                        
                        
                        <button type="button" class="btn btn-default"  onclick="AddText(this.form,5);return false;" data-toggle="tooltip" title="Italic">
                            <i class="fa fa-italic"></i>
                        </button>
                        <button type="button" class="btn btn-default" onclick="AddText(this.form,21);return false;" data-toggle="tooltip" title="Underline">
                            <i class="fa fa-underline"></i>
                        </button>
                         <button type="button" class="btn btn-default"  onclick="AddText(this.form,7);return false;"data-toggle="tooltip" title="Break">
                         
                            <i "><b>BR</b></i>
                        </button>
                        
                        <button type="button" class="btn btn-default"  onclick="AddText(this.form,8);return false;"data-toggle="tooltip" title="Line">
                         
                         <i class="fa fa-minus"> </i>
                         
                           </button>
                    </div>
                   
                    <div class="btn-group">
                        <button type="button" class="btn btn-default" onclick="AddText(this.form,18);return false;" data-toggle="tooltip" title="Align left">
                            <i class="fa fa-align-left"></i>
                        </button>
                        <button type="button" class="btn btn-default" onclick="AddText(this.form,19);return false;"  data-toggle="tooltip" title="Align center">
                            <i class="fa fa-align-center"></i>
                        </button>
                        <button type="button" class="btn btn-default" onclick="AddText(this.form,20);return false;"  data-toggle="tooltip" title="Align right">
                            <i class="fa fa-align-right"></i>
                        </button>
                        
                    </div>
                    <div class="btn-group">
                     
                        
                        <button type="button" class="btn btn-default" onclick="AddText(this.form,22);return false;"  data-toggle="tooltip" title="Bulleted list">
                            <i class="fa fa-list-ul"></i>
                        </button>
                        
                        
                        <button type="button" class="btn btn-default"   onClick="showMediaList();return false;" data-toggle="tooltip" title="Media List">
                            <i class="fa fa-list-ol"></i>
                        </button>
                        
                    </div>
                    <div class="btn-group">
                        <button type="button" class="btn btn-default" onClick="showAnchor();return false;" data-toggle="tooltip" title="Link">
                            <i class="fa fa-link"></i>
                        </button>
                        
                   
                        <button type="button" class="btn btn-default" onclick="AddText(this.form,10);return false;"  data-toggle="tooltip" title="Picture">
                            <i class="fa fa-picture-o"></i>
                        </button>
                        
                        <button type="button" class="btn btn-default" data-toggle="tooltip" title="Font">
                            <i class="fa fa-font"></i>
                        </button>
                        </div>  <div class="btn-group">
                        <button type="button" class="btn btn-default"  onClick="showVideoForm();return false;" data-toggle="tooltip" title="HTML5 Video">
                            <i class="fa fa-html5"></i>
                        </button>
                        
                         <button type="button" class="btn btn-default"  onClick="showAudioForm();return false;" data-toggle="tooltip" title="HTML5 audio player">
                            <i class="fa fa-music"></i>
                        </button>
                        
                         </div>
          

 <div class="panel-body">

            
<textarea name="file"  class="form-control" rows="40" cols="170" id="body"style=" font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width:773px;"><?php echo $loadfile; ?></textarea>
 <p>
 <input class="form-control" type="hidden"   name="filename" id=data value="<?php echo $fname; ?>" size="70" style=" font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 608px;"/>  
<input class="btn btn-danger" class="form-control"type="submit" name="save_file" value="Update" style=" font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 2px; width: 88px;"/>
 </div>
 
 </div>
 </div>
 
 
<div id="anchor" >
<div id="draggable" class="panel panel-default" style="position:absolute; left:601px;top:0px; background-color:#F7F7F7;background-image:url(); z-index:0;  width:430px;">	


<div class="panel-heading" >
                       Link / Anchor Properties
                        </div>
            <div class="panel-body">

<table  border="0" cellpadding="0" cellspacing="0" style="padding: 10px;"><tr>
<td>
<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold;">Insert Anchor:</span>

	  <button type="button" class="btn btn-default" onclick="AddText(this.form,9);return false;" data-toggle="tooltip" title="Link">
                            <i class="fa fa-link"></i>
                        </button>
   <br>
  
<table width="380" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 0px;">
 <tr>
  <td style="padding-bottom: 2px; width: 50px; font-family: arial, verdana, helvetica; font-size: 11px;">Type:</td>
	<td style="padding-bottom: 2px;">
	<select name="AnchorType" id="linkType" style="margin-right: 10px; font-size: 11px; width: 100%;"">
	 <option value="">Not Set</option>
	 <option value="http://">http:</option>
	 <option value="https://">https:</option>
	  <option value="mailto:">mailto:</option>
	</select>
	</td>	
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100">Alignment:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	<select name="alignment"  style="font-family: arial, verdana, helvetica; font-size: 11px; width: 100%;">
	 <option value="">Not Set</option>
	 <option value="left">Left</option>
	 <option value="right">Right</option>
	 <option value="texttop">Texttop</option>
	 <option value="absmiddle">Absmiddle</option>
	 <option value="baseline">Baseline</option>
	 <option value="absbottom">Absbottom</option>
	 <option value="bottom">Bottom</option>
	 <option value="middle">Middle</option>
	 <option value="top">Top</option>
	</select>
	</td>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;" width="100"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;" width="85">
	
	</td>
 </tr>
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;">Anchor Name:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="anchor" id="link" value=""  style="font-size: 10px; width: 100%;"></td>
 
 </td>	
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;">URL:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="AnchorUrl" id="url" value=""  style="font-size: 10px; width: 100%;"></td>
</tr>

 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;"></td>
	<td style="padding-bottom: 2px; padding-top: 0px;">
	
	             
	
<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 147px; width: 62px;top:0px;" onClick="hideAnchor();return false;">Close</button>

	
</td>
</tr>

</table>	
 </tr>
</table>	
</div></div></div>

<div id="audioform" >
<div  id="draggable2" class="panel panel-default" style="Z-INDEX: 27; POSITION: absolute; background-color: #F7F7F7;   TOP: 266px; LEFT: 700px;">   
      
<div class="panel-heading" >
                        Audio Properties
                        </div>
          
       <div class="panel-body ">   
       	Insert
<button type="button" class="btn btn-default"  onclick="AddText(this.form,14);return false;" data-toggle="tooltip" title="Insert AudioPlayer">
      <i class="fa fa-music"></i>
                        </button ><br/><br/>
<input class="" type="text" name="audio" value="Audio URL" size="60" /><P>
<input class="" type="text" name="audio_width" value="AudioPlayer Width" size="20" />
<br/><br/>
<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 147px; width: 62px;top:0px;" onClick="hideAudioForm();return false;">Close</button>
                       
</div></div></div></div>


<div id="videoform">
<div id="draggable3" class="panel panel-default" style="Z-INDEX: 27; POSITION: absolute; background-color: #F7F7F7;  TOP: 266px; LEFT: 450px;">
 
    <div class="panel-heading" >
                        Video Properties
                        </div>
 <div class="panel-body" >
                        
 	Insert
<button type="button" class="btn btn-default"  onclick="AddText(this.form,15);return false;" data-toggle="tooltip" title="Insert AudioPlayer">
      <i class="fa fa-html5"></i>
                        </button><br/><br/>
<input class="" type="text" name="video" value="Video URL" size="60" /><P>
<input class="" type="text" name="video_poster" value="Video-Image-Poster" size="60" /><P>
<input class="" type="text" name="video_width" value="VideoPlayer-Width" size="20" />
<br/><br/>
<button class="btn btn-primary" style="font-size: 10px; font-family: arial, verdana, helvetica, sans serif; margin-left: 147px; width: 62px;top:0px;" onClick="hideVideoForm();return false;">Close</button>
                       
   </div></div></div></div>
         
         
</div>
</form>

		
<div id="bv_Text1" style="position:absolute;left:61px;top:307px;width:250px;height:16px;z-index:3;" align="left">

			
            </div>
		</div>
	</div>
</div>
<center>
	<script type="text/javascript">
	
	</script>
</body>
</html>